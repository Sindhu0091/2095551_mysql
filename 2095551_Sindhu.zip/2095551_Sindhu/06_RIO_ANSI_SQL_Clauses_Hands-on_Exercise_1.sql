-- Problem 1: Develop a sql query which would retrieve the number of associates enrolled for modules
--  on a specific date grouped by start date and display start date and total number of associates.
select Start_date, count(*) as total_no_of_associate_joined from Associate_Status group by Start_date;


-- Problem 2: Develop a sql query which would retrieve the number of associates enrolled for modules
-- where trainer id is ‘F001’ grouped by start date and display start date and total number of associates.
select Start_date, count(*) as number_of_associates from Associate_status where Trainer_Id = 'F001' group by Start_date;



-- Problem 3: Develop a sql query which would retrieve the number of associates enrolled for modules
-- where trainer id is ‘F001’ grouped by module start date and display module start date and total
-- number of associates where the total number of associates > 2.
select Start_date, count(*) as number_of_associates from Associate_status group by Start_date having count(*)>2;



-- Problem 4: Develop a SQL query which displays all the modules in increasing order of module duration.
select * from Module_info order by Module_Duration;



-- Problem 5: Develop a sql query which would retrieve and display the associates name, their module
-- enrolled (module name and module id), base fees. Display the records ordering the base fees in
-- descending order.
select a.Associate_name, m.Module_id, m.Module_name, m.Module_fees from Associate_status as astatus
inner join associate_info as ainfo on a.Associate_Id = astatus.Associate_Id
inner join Module_info as m on m.Module_Id = astatus.module_Id
order by m.module_fees desc;