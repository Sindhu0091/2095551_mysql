 
create table Student_Info_12(
Reg_Number Varchar(20) primary key, Student_Name Varchar(30), Branch Varchar(20), 
Contact_Number Varchar(12), Date_of_Birth Date, Date_of_Joining Date, Address Varchar(250),
Email_id Varchar(250));

create table Subject_Master_12(
Subject_Code varchar(10), Subject_Name Varchar(30), Weightage int3);

create table Student_Marks_12(
Reg_number varchar(20), Subject_code varchar(20), Semester int, marks int);

create table Student_Result_12(
Reg_Number Varchar(20), Semester int, GPA float, Is_Eligible_Scholarship varchar(10));
 
 



insert into Student_Info_12 values(
 'MC101301','James', 'MCA', '9714589787', '1984-01-12', '2010-07-08', 'No 10,South Block,Nivea', 'james.mca@yahoo.com'),
 ('BEC111402','Manio', 'ECE', '8912457875', '1983-02-23', '2010-07-25', '8/12,Park View,Sieera', 'manioma@gmail.com'),
 ('BEEI101204','Mike', 'EI', '8974567897', '1983-02-10', '2010-08-25', 'Cross villa,NY', 'mike.james@ymail.com'),
 ('MB111305','Paulson', 'MBA', '8547986123', '1984-12-13', '2010-08-08', 'Lake view,NJ', 'paul.son@rediffmail.com');
 
 
 insert into Subject_Master_12 values(
 'EE01DCF','DCF',30),
('EC02MUP','Microprocessor',40),
('MC06DIP','Digital Image Processing',30),
('MB03MAR','Marketing Techniques',20),
('EI05IP','Instrumentation Precision',40),
('CPSC02DS','Data Structures',40);


insert into Student_Marks_12 values(
'MC101301', 'EE01DCF', 1, 75),
('MC101301', 'EC02MUP', 1,65),
('MC101301', 'MC06DIP', 1, 70),
('BEC111402', 'EE01DCF', 1, 55),
('BEC111402', 'EC02MUP', 1, 80),
('BEC111402', 'MC06DIP', 1, 60),
('BEEI101204', 'EE01DCF', 1,85),
('BEEI101204', 'EC02MUP', 1, 78),
('BEEI101204', 'MC06DIP', 1, 80),
('BEEI101204', 'MB03MAR', 2, 75),
('BEEI101204', 'EI05IP', 2, 65),
('BEEI101204', 'CPSC02DS', 2, 75),
('MB111305', 'EE01DCF', 1, 65),
('MB111305', 'EC02MUP', 1, 68),
('MB111305', 'MC06DIP', 1, 63),
('MB111305', 'MB03MAR', 2, 85),
('MB111305', 'EI05IP', 2 ,74),
('MB111305', 'CPSC02DS', 2, 62);


insert into Student_Result_12 values
('MC101301', 1, 7.5, 'Y'),
('BEC111402', 1, 7.1, 'Y'),
('BEEI101204', 1, 8.3, 'Y'),
('BEEI101204', 2, 6.9, 'N'),
('MB111305', 1, 6.5, 'N'),
('MB111305', 2, 6.8, 'N');




 -- Problem # 1: Write a query to display student information such as name, branch in capital letters.
 
 select Student_Name, Branch, upper(Student_Name), upper(Branch) from Student_Info_12;
 
 
--  Problem # 2:Write a query to displays all details in subject_master in small letters.
 
 select lower(Subject_Code) from Subject_Master_12;
 
 
 
 
 
 -- Problem # 3:Write two separate queries to display the registration number 
 -- date of birth of all the students in the following formats
 -- 2011/07/23 , July 23, 2011
 
 select Reg_Number, Date_of_Birth, date_format(Date_of_Birth, '%Y/%m/%d') from Student_Info_12;
 
 select Reg_Number, Date_of_Birth, date_format(Date_of_Birth, '%M %d,%Y') from Student_Info_12;
 
 
 -- Problem # 4:Write a query to display age of each student along with name, contact number and email id.
 -- Age = Number of months between DOB and current date /12
 
 select Student_Name,Contact_Number,Email_id, datediff(current_date(), date_of_birth)/12 as 
" age = Number of months between DOB and current date /12 " from Student_Info_12;
 
 -- Problem # 5:Write a query to display the registration number, student name 
 -- and average marks secured by students in each semester
 
 select S.Reg_Number,S.Student_Name,Stu.Semester, avg(Stu.marks) from  Student_Info_12 S  
 inner join Student_Marks_12 stu on  Stu.Reg_Number=  S.Reg_Number group by Stu.Semester  ;
 
 -- Problem # 6:Pick the maximum mark from the students_marks and 
-- display the student registration number and name of those students who have secured the maximum mark.
 
  select S.Reg_Number,S.Student_Name,Stu.Semester, Stu.marks from 
  Student_Marks_12 as Stu inner join Student_Info_12 as S on  Stu.Reg_Number= S.Reg_Number; 
   
 
 -- problem 7 Pick the maximum marks secured in the subject “ EI05IP” and display
 --  the student name and registration number of the student who has secured it.
 
select S.Student_Name , max(marks) from Student_Info_12 as S
inner join  Student_Marks_12 as  Stu on Stu.Reg_Number= S.Reg_Number
where Subject_Code = 'EI05IP';

-- Problem # 8:Write a query to display the average GPA for each semester. Display the semester number and the average.
-- Hint: Average = Total GPA of all students in a semester/total number of students in a semester
-- Rule: Use AVG function
select Semester, avg(GPA) from Student_Result_12 group by Semester;

--- Problem # 9:display all the student records, if the student email id is null it should be displayed 
--             as “no valid email address”.
select Student_Name , Reg_Number,Branch, Contact_Number,Date_of_Birth,Date_of_Joining,Address,
case when Email_id is null then 'no valid email address'
else Email_id end as email_id   from Student_Info_12;

--- Problem # 10:Write a query which will display the student name, branch, registration number, 
-- semester number and result. Display the full name of EEE as well as ECE branch as mentioned below,
-- If EEE then ‘Electrical and Electronic Engineering’
-- If ECE then Electronics and Communication Engineering.

select S.Student_Name, case when Branch = 'EEE' then 'Electrical and Electronic Engineering'
                     when Branch = 'ECE' then 'Electronics and Communication Engineering'
                     else Branch end as Branch, S.Reg_Number,
Stu.Semester,  Stu.GPA
from Student_Info_12 as S
inner join Student_Result_12 as Stu on Stu.Reg_Number= S.Reg_Number;