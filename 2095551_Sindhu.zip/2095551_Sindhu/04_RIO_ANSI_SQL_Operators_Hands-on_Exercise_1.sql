create database opehandon;
use opehandon;

create table trainers_info(
trainer_id varchar(20), Salutation varchar(7), Trainer_Name varchar(30),
Trainer_Location varchar(30), Trainer_Track varchar(15), Trainer_Qualification varchar(100),
Trainer_Experiance int, Trainer_Email varchar(100), Trainer_Password varchar(20));

alter table trainers_info modify  Trainer_Email varchar(100) null;


insert into trainers_info values
('F001','Mr.','OMER GHOSH','Pune','Java','Bachelor of Technology',12,'Pankaj.Ghosh@alliance.com','fac1@123'),
('F002','Mr.','SANJAY RADHAKRISHNAN ','Bangalore','DotNet','Bachelor of Technology',12,'Sanjay.Radhakrishnan@alliance.com','fac2@123'),
('F003','Mr.','MATHURI','Chennai','Mainframe','Bachelor of Technology',10,'Vijay.Mathur@alliance.com','fac3@123'),
('F004','Mrs.','NANDINI NAIR','Kolkata','Java','Master of Computer Applications',9,'Nandini.Nair@alliance.com','fac4@123');


 insert into trainers_info(trainer_id, Salutation, Trainer_Name,
Trainer_Location, Trainer_Track , Trainer_Qualification,
Trainer_Experiance ,Trainer_Password) values
('F005','Miss.','ANITHA PAREKH','Hyderabad','Testing','Master of Computer Applications',6,'fac5@123');


select Trainer_Name from trainers_info
where Trainer_Email is null;

select trainer_id,Trainer_Name,Trainer_Track,Trainer_Location from trainers_info
where Trainer_Experiance > 4;

select trainer_id,Trainer_Name,Trainer_Qualification from trainers_info
where Trainer_Qualification != 'Bachelor of Technology';

select trainer_id,Trainer_Name from trainers_info
where Trainer_Name like 'M%';

select trainer_id,Trainer_Name from trainers_info
where Trainer_Name like '%o%';

create table Module_Info(
Module_Id varchar(20) , Module_Name varchar(40) , Module_Duration int );

insert into Module_Info values
('MSBI08','MS BI Studio 2008',158),
('SHRPNT','MS Share Point' ,80),
('ANDRD4','Android 4.0',200),
('EM001','Instructor',300),
('EM002','Course Material',250),
('EM003','Learning Effectiveness',0),
('EM004','Environment',290);

select Module_Id, Module_Name , Module_Duration from Module_Info 
where Module_Duration >200;

select Module_Id, Module_Name , Module_Duration from Module_Info 
where Module_Duration >200 and Module_Duration < 300;

select Module_Id, Module_Name , Module_Duration from Module_Info 
where Module_Name is not null;



create table Student_Info12( 
Reg_Number Varchar(20), Student_Name Varchar(30),mail_id Varchar(250));
 
 create table Subject_Master_123(
Subject_Code varchar(10), Subject_Name Varchar(30), Weightage int3);
 alter table Subject_Master_123 add Reg_Number Varchar(20);
 

create table Student_Marks_123(
Reg_number varchar(20), Subject_code varchar(20), Semester int, marks int);

rename table Student_Marks_123 to marks;

create table Student_Result_123(
Reg_Number Varchar(20), Semester int, GPA double, Is_Eligible_Scholarship varchar(20));


 
 insert into  Student_Info12 values 
('MC101301','James','james.mca@yahoo.com'),
('BEC111402','Manio','manioma@gmail.com'),
('BEEI101204','Mike', 'mike.james@ymail.com'),
('MB111305','Paulson', 'paul.son@rediffmail.com');

insert into Subject_Master_123 values(
 'EE01DCF','DCF',30),
('EC02MUP','Microprocessor',40),
('MC06DIP','Digital Image Processing',30),
('MB03MAR','Marketing Techniques',20),
('EI05IP','Instrumentation Precision',40),
('CPSC02DS','Data Structures',40);


insert into Student_Marks_123 values(
'MC101301', 'EE01DCF', 1, 75),
('MC101301', 'EC02MUP', 1,65),
('MC101301', 'MC06DIP', 1, 70),
('BEC111402', 'EE01DCF', 1, 55),
('BEC111402', 'EC02MUP', 1, 80),
('BEC111402', 'MC06DIP', 1, 60),
('BEEI101204', 'EE01DCF', 1,85),
('BEEI101204', 'EC02MUP', 1, 78),
('BEEI101204', 'MC06DIP', 1, 80),
('BEEI101204', 'MB03MAR', 2, 75),
('BEEI101204', 'EI05IP', 2, 65),
('BEEI101204', 'CPSC02DS', 2, 75),
('MB111305', 'EE01DCF', 1, 65),
('MB111305', 'EC02MUP', 1, 68),
('MB111305', 'MC06DIP', 1, 63),
('MB111305', 'MB03MAR', 2, 85),
('MB111305', 'EI05IP', 2 ,74),
('MB111305', 'CPSC02DS', 2, 62);


insert into Student_Result_123 values
('MC101301', 1, 7.5, 'Y'),
('BEC111402', 1, 7.1, 'Y'),
('BEEI101204', 1, 8.3, 'Y'),
('BEEI101204', 2, 6.9, 'N'),
('MB111305', 1, 6.5, 'N'),
('MB111305', 2, 6.8, 'N');


select Reg_Number , Student_Name ,mail_id from Student_Info12
where mail_id is not null;

select Reg_Number, marks from  Student_Marks_123 
where marks >50;

select Reg_Number, Semester, GPA , Is_Eligible_Scholarship from Student_Result_123
where Is_Eligible_Scholarship = 'Y' or Is_Eligible_Scholarship  != 'Y';

select Reg_Number , Student_Name from Student_Info12
where Student_Name like 'M%';


select Reg_Number , Student_Name from Student_Info12
where Student_Name not like 'j%';

select Reg_Number , Student_Name from Student_Info12
where Student_Name like '%on';

select Reg_Number,Subject_code, Semester, marks from marks
where Subject_code= 'EE01DCF'  || Subject_code= 'EC02MUP' ;
 
 
 

