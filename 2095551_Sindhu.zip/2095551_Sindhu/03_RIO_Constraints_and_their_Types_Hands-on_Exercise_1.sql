create database conshandson;
use conshandson;

create table Trainer_Info (
Trainer_Id varchar(20) primary key, Salutation varchar(7), Trainer_Name varchar(30),
Trainer_Location varchar(30), Trainer_Track varchar(15), Trainer_Qualification varchar(100),
Trainer_Experiance int not null, Trainer_Email varchar(100), Trainer_Password varchar(20));

 alter table Trainer_Info modify Trainer_Experiance int null;
 
 alter table Trainer_Info add constraint Trainer_Id_ckk check (Trainer_Id (starts ('F')));
 
 drop table  Trainer_Info;
 
 create table Trainer_Info (
Trainer_Id varchar(20) primary key, Salutation varchar(7), Trainer_Name varchar(30),
Trainer_Location varchar(30), Trainer_Track varchar(15), Trainer_Qualification varchar(100),
Trainer_Experiance int null, Trainer_Email varchar(100), Trainer_Password varchar(20),
constraint Trainer_Id_ckk check (Trainer_Id like 'F%'));

create table Batch_Info (
Batch_Id varchar(20) primary key, Batch_Owner varchar(20), Batch_BU_Name varchar(30),
constraint Batch_Id_ckk check (Batch_Id like 'B%'));

create table Module_Info(
Module_Id varchar(20) not null, Module_Name varchar(40) not null, Module_Duration int not null,
 constraint Module_Id_ckk check (Module_Id like '[A-Z]'));
 
 alter table Module_Info modify Module_Id varchar(20) not null primary key;
 
 
 create table Associate_Info(
Associate_Id varchar(20)not null, Salutation varchar(7)not null, Associate_Name varchar(30)not null,
Associate_Location varchar(30)not null, Associate_Track varchar(15)not null, Associate_Qualification varchar(100)not null,
Associate_Experiance int not null, Associate_Email varchar(100)not null, Associate_Password varchar(20)not null,
constraint Associate_Id_ckk check (Associate_Id like 'A%'));

alter table Associate_Info modify Associate_Id varchar(20) not null primary key;


create table Questions(
Question_Id varchar(20) not null primary key, Module_Id varchar(20)not null, Question_Text varchar(900)null,
constraint Question_Id_ckk check (Question_Id like 'Q%'), 
constraint fk_Module_Id foreign key (Module_Id) references Module_Info(Module_Id));


create table Associate_Status(
Associate_Id varchar(20) not null, Module_Id varchar(20) not null, Batch_Id varchar(20) not null,Trainer_Id varchar(20) not null,
Start_Date varchar(20) null, End_Date  varchar(20) null,
AFeedbackGiven varchar(20) null,TFeedbackGiven varchar(20) null,
constraint fk_Associate_Id foreign key (Associate_Id) references Associate_Info(Associate_Id),
constraint fk_Batch_Id foreign key (Batch_Id) references Batch_Info(Batch_Id),
constraint fk_Trainer_Id foreign key (Trainer_Id) references Trainer_Info(Trainer_Id));

create table Trainer_Feedback(
Associate_Id varchar(20) not null, Module_Id varchar(20) not null, Batch_Id varchar(20) not null,Trainer_Id varchar(20) not null,
Trainer_Rating varchar(20) not null);

create table Associate_Feedback(
Associate_Id varchar(20) not null, Module_Id varchar(20) not null, Trainer_Id varchar(20) not null, 
Associate_Rating varchar(20) not null);




create table product(
productID int primary key, productname varchar(20),
productprice int not null);
drop table product;

/* ex 3.2*/


create table product(
productID int primary key, productname varchar(20),
productprice int not null);
 alter table product modify productprice int;


create table user(
userID varchar(10) primary key, productID int, username varchar(20),
constraint fk_productID foreign key(productID) references product(productID));

insert into product values (1,'A Dongle',290),
 (2,'B Dongle',1250);

insert into product(productID,productname) values ( 3,'C Dongle');

alter table user  drop foreign key fk_productID;

insert into user(userID, productID, username) values ( 'U001',1,'Ramesh'),('U002',11,'Mahesh');

/*ex 3.3*/

create table Student_Info(
Reg_Number varchar(20) primary key, Student_Name varchar(30) not null, Branch varchar(30),
Contact_Number varchar(30), Date_of_Birth date, Date_of_Joining date);

create table Subject_Master(
Subject_Code varchar(20) primary key,Subject_Name varchar(30) not null, Weightage int not null);


create table Student_Marks(
Reg_Number varchar(20), Subject_Code varchar(20),Semester int not null, Marks int,
constraint fk_Reg_Number foreign key(Reg_Number) references Student_Info(Reg_Number),
constraint fk_Subject_Code foreign key(Subject_Code) references Subject_Master(Subject_Code));

alter table Student_Marks modify Semester int not null primary key;
alter table Student_Marks modify Marks int default 0;

create table Student_Result(
Reg_Number varchar(20),Semester int not null,GPA int not null,Is_Eligible_Scholarship varchar(20) default 'yes');









 


